## Workshop Agenda

    1. Class Components
    2. Ownership related controls

    3. Profiler
    4. Use callback
    5. Use memo
    6. React memo
    
    7. Compound component
    9. Sorting
    10. Search
    11. Pagination
    12. Clear form
